Please refer to this page for more information:
http://wiki.neo4j.org/content/Neoclipse
